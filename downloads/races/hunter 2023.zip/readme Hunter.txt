Read me: Hunter for TAKS

Author: Timothy Call

Version: 1

Instructions unpack zip and put the files into your Races folder...

Disclaimer: There is no warranty, guarantee or responsibility on my part.

Monarch: Serdrin

Builder One: Advisor

Builder Two: Wild Pegasus

Builder Three: Druid

Builder Four: Enlightened Priest

Have fun