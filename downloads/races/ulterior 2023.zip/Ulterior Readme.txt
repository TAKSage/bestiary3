Ulterior 1.0

After the war with Creon, the people of Veruna sailed out to discover new worlds.

The found an entire unexplored continent. One populated with magics never seen before en gods never heard of.

Soon, they knew that their worlds would soon meet one and another. Some as allies, but some would come to them as enemies.

The magic forces of Delean...

The divine Ulterior...

And the mysterious Ficedulea...

-----------------------------------------

How to install and use:

::Without TAKS:: 
(for usage with TAK:Switcher : "http://www.mtmcwebdesigns.com/tak/forum/forum/topic.asp?TOPIC_ID=442"
or "http://www.fileuniverse.com/?p=showitem&ID=3848")

-Place the "UlteriorV1.ufo" file in your "Kingdoms" folder
-Apply "Kingdoms.exe -disablecavedogverification"
-Startup

OR

use the shortcut that's included in the .zip file.

-----------------------------------------

Units:

Aetherius Blimp
This is the tier 4 air unit of Ulterior. It is slow, but can do a lot of damage by bombing. Powered by the magics of the 
monolith, this unit is a match to the other races' dragons.

Antaeus
Mobile tower with ribaud. Very slow and very expensive. Used in small numbers to lead an attack.

Apricor Lens
Uses prismatic mirror like technology, but not to concentrate the light to burn the target, but it creates a bundle of light
that makes the first thing caught in it's beam reflect the light, causing an explosion.

Armoury
Tier1 factory

Architect
Can build Tier 4 buildings and units.

Artifex
The divine one. This is the monarch of Ulterior. The magics of the monolith have given him technical greatness. It is unknown
what part of him is human, technology or magic.

Dreadbolt
Fires heavy rockets over a longer distance. Fireworks siege weapon.

Factory
Tier 3 factory.

Fireworker
Light ranged unit that fires different types of rocket at target.

Fourier
Light melee unit. Not very strong. Main goal is to keep other melee units away from Ulterior ranged.

Gate
Same as other races' gate.

Gunboat
Steam powered vessel with mortar. Good at bombing targets from the sea.

Manalith
Generates mana. Built like the usual lodestone.

Mobile Tower
Siege tower with flame thrower. Use as a siege weapon. Don't use it against speedy ranged units.

Monodivinitus
The god. Does area of effect damage. Explodes when destroyed. Not as strong as most gods, but also cheaper and it gives an
economy bonus.

Monolith
Generates mana. Built like the usual lodestone.

Ornithopter
Bomber. Slow and vulnerable, but can do a great deal of damage. Weak versus moving targets.

Portus
Ulterior tier 2 (naval) factory.

Ribaud
Machine gun like cannon. Barrels revolve and a rapid fire is caused. After some shots, the barrels tend to overheat, so it
must cool down for a while.

Rocket Tower
Quite weak tower. Fires rockets that almost hit instantly.

Steamferry
Transport ship, but also usable in naval combat.

Structor Balloon
Builder. Moves slow and makes an easy target for faster units.

Wall
Same as other races' wall.

Volo Machine
Light airplane. Used mainly as a scout or support bomber. Don't use it to bomb fortified bases.
