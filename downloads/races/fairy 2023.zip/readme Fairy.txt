Read me: Fairy for TAKS

Author: Timothy Call

Version: 1

Instructions unpack zip and put the files into your Races folder...

Disclaimer: There is no warranty, guarantee or responsibility on my part.

Monarch: Fairy Princess 

Builder One: Brownie Shaman

Builder Two: Sprite

Builder Three: Elven Mage

Builder Four: Ice Pixie

Builder Five: Fairy Lifegiver

Builder Six: Genie

Have fun