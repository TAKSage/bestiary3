T-mod: a Total Annihilation Kingdoms enhancement by Trouvere

This is version T1.3.3, intended for use with Kingdoms version 3.0
and the Iron Plague expansion.  This is a development release.  It
may have bugs.  In particular, I wouldn't be surprised to find that
it is incompatible with Kingdoms installations that do not have the
Iron Plague expansion installed.  Please send in bug reports or
suggestions if you have them.  The most recent stable release at
this time is T1.2.0.

Files included in this distribution:
   Kingdoms\T-mod.hpi
   Kingdoms\T-mod\README.txt
   Kingdoms\T-mod\TA Kingdoms with mods.lnk

Installation instructions:

1. Unpack the .zip archive directly into your Kingdoms directory,
   overwriting any files with the same names which may already exist.
2. Start Kingdoms by double-clicking the "TA Kingdoms with mods"
   shortcut in the T-mod directory (under your Kingdoms directory).
   You may want to move this shortcut to your desktop or another
   convenient location.
3. Note that you can also start Kingdoms from you Start menu or
   existing shortcuts.  These will start Kingdoms without the mods.
4. Note that the shortcut provided in this distribution will only work
   if you have installed Kingdoms in the default location.  If you
   have installed Kingdoms in another location, you can make your
   own special shortcut like this:

   1. Create a shortcut to Kingdoms.
   2. Right-click on it and select "Properties".
   3. append " -disablecavedogverification" (without the quotes) to
      the "Target" field.
   4. Click "OK".
   5. Rename your shortcut to "TA Kingdoms with mods" or something
      similar.

For much more information please see:

http://www.ossmann.com/kingdoms/

Thank you for trying T-mod!

- Trouvere <mike@ossmann.com>


Change log:
T1.3.3
 - made Taros Black Knight freezable.
 - made Aramon Horseman freezable.
 - made Aramon Knight unfreezable.
 - added Aramon Rolling Tower to Acolyte's build menu.
 - fixed Deer "watermultipliser" typo.  (How did these pop up again?)
 - fixed Buck "watermultipliser" typo.
 - fixed Saber Tooth Tiger "admultiplier" typo.
 - fixed Veruna Ballista "roadmultplier" typo.
 - fixed Aramon Grenadier "vetmodel" typos.
   (When was the last time you saw a veteran Grenadier?  :-)
T1.3.2
 - fixed nasty Aramon test unit bug.  (Big oops!)
 - Sage first weapon damage decreased to 1350 (originally 1010).
 - Sage first weapon manapershot increased from 0 to 90.
 - Sage first weapon reloadtime increased from 2.0 to 2.5.
T1.3.1
 - Creon Chief Engineer made able to build-assist.
 - Sage sightdistance increased from 232 to 500.
 - Sage radardistance increased from 650 to 1000.
 - Sage first weapon damage increased from 1010 to 2800.
 - Sage first weapon dragon damage increased from 1.0 to 2.0.
 - added Creon Wall to T1.3.0 change log.  (oops!  :-)
T1.3.0
 - established new baseline: CUT3 (crusades balance).
 - added 3rd party Side Gates courtesy of DL_Recca and Z-TA.
 - Aramon Acolyte made able to build-assist.
 - Taros Dark Priest made able to build-assist.
 - Veruna Priest of Lihr made able to build-assist.
 - Zhon Shaman made able to build-assist.
 - made Aramon Wall reclaimable (clearable) at 10 seconds per segment.
 - made Creon Wall reclaimable (clearable) at 10 seconds per segment.
 - made Veruna Wall reclaimable (clearable) at 10 seconds per segment.
 - made Taros Wall reclaimable (clearable) at 10 seconds per segment.
 - added Beast Handler to Zhon Beast Lord's build menu.
 - Veruna Mer Warrior naval damage modifier reduced from 1.5 to 0.3.
 - Zhon Swamp Beast naval damage modifier reduced from 1.25 to 0.3.
 - Zhon Beast Handler damagecategory changed from stalwart to monster.
 - Zhon Beast Tamer damagecategory changed from stalwart to monster.
 - Zhon Beast Lord damagecategory changed from stalwart to monster.
 - Zhon Shaman damagecategory changed from stalwart to monster.


Credits:

While coordinated by a single person, the T-mod is very much a community effort.  Nearly 100% of the ideas reflected in the mod have come from other members of the community who have offered their suggestions for discussion on the public forums.

Special thanks to. . .

 - DL_Recca and Z-TA for contributing the side gates.
 - Joe D. for his HPI utilities and all the hard work he puts into supporting the 3rd party community.
 - Gigaflop for inspiration and advocacy.
 - Jugularos for helping figure out how to make walls reclaimable.
 - Roldan for suggesting the inclusion of the shortcut.
 - Bish0p for helping figure out how the game responds to multiplayer mod-mismatches and such.
 - Brave Sir Robin for advice and TA vs. TAK internals expertise.
 - Corinne and Flatiron for the Dirigible bomb range suggestion.
 - Postal for exceptionally level-headed suggestions.
 - Everyone on the Annihilated and Cavedog forums for all the great suggestions and moral support.
 - TTLB for being TTLB.
 - Cavedog for making a great game, continuing to support it, and even adopting some of the changes in previous versions of T-mod.
 - CyberCerberus and WingedElf for their hard work on the CUT.
 - Everyone who played on the T-mod ladder.
