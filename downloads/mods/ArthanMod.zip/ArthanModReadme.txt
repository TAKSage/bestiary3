- < Total Annihilation: Kingdoms -- { ArthanMod } > -


How to play: 
1)Assuming you have TAK and the 4.1bb patch installed.
2)Install TAK Switcher
3)Place ArthanMod.ufo into the "MODS" folder.
4)Remove Kingdoms.key file. (Place it on your desktop, you will need it
if you decide to play on Warzone)
5)Click the <-Launch TAKS-> button.
6)You can play single player 
7)Or you can host/join games via IP Address!!!!

8)Put Kingdoms.key file back into your folder, after you are done,
 if you choose to play TAK via Warzone

* This mod may work fine even without removing the kingdoms.key from your tak directory.

*A few words about this mod:

 This simple mod was created by ARTHAN from Total Annihilation: Kingdoms Community
(visit our site at http://kingdoms.heavenforum.org) in order to offer a new kind
of TAK experience to the gamer. It adds more variety of units while making the
game much more balanced for sure, since you will be able to train units and buildings
your opponent has. Here are the differences of the original TAK:

[1) Each of the five monarchs can summon his/her respective tier 1 builder. For example,
 Elsin can summon a Mage Builder without constructing a Barracks first and training him
 there, The Sage can train a Mechanic right away without building a Smithy first etc.

[2) Each of the five monarchs can summon a high-tier unit. This enables these units to
 enter the battlefield earlier than before, making them more useful. Thirsa can call
 Wisps, Lokken can conjure Dark Hands, The Sage is able to train Shock Troopers,
 Kirenna creates Ballistas and Elsin makes Grenadiers.

[3) Each monarch will be able to summon the tier 1 builder of another civilization, if
 that civilization is present on the map. This was made in order to maintain balance
 even when the odds are uneven. For example, The Sage can train Priestesses and Dark
 Masons along with his Mechanics as long as a Veruna and a Taros player exist. Notice
 that this will make all the players able to train the same units.

[4) If the nation of Aramon is present on the map, the monarchs of the rest players
 will be able to summon the Ark, even if they are not Aramon players.

[5) Thirsa can build the Gate of each other race, as long as that race is present on
 the battlefield. Obviously, this was made in order to give Zhon a chance in 1v1
 online matches taking place on 3rd party maps.

* This mod is NOT copywrited in any way, feel free to change it as you please... However,
 I hope you willl enjoy playing this mod as much as I did! Long live TA:K!!!

