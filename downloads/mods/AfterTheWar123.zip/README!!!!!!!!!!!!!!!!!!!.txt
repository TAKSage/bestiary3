
!!! There is a detailed manual (in .PDF format) about the mod in the package named After the war manual. !!!

Press F4 ingame for some quick help about the mod.

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

Installation:

To be able to play with the mod without problems you first need to make sure you have the expansion Iron Plague installed with the last patch for TA:K . (When this manual was written out the last patch was 4.1BB .)
Then simply extract the .fbi file in your kingdoms folder.
Search for the file named �Kingdom.key� and rename it into �Kingdom.key.disable�. (Don�t delete it!)
You may need to rename that file back if you don�t want to play with mods.
You can leave the mod file where it is since all mods are disabled if �kingdom.key� isn�t deleted or renamed.

DO NOT use TAK SWITCHER with after the war or you may encounter some bugs !

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

i still need feedback to balance and change stuff so feel free to contact me on discord. (ako)
i can also be found on deekay's TAK discord server under the same pseudo.

most icons i made for units picture, except the ones in white and black, are all of a bad quality because the game support only .jpeg and this file extension compress picture upon saving to a degree that all colors lose their brightness and shape.

i hope you ll have fun with my work :)


!!!!!!!!!!!!Disclaimer!!!!!!!!!!!!!!: the TAKhelper.ufo is a special mod that gives you a super unit for all 5 races that build very fast for testing purpose.
this mod is also compatible with the azurian, ethian and the cursed factions.
(which are featured in the equinox mod.)

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

CREDITs: 

creator of the mod : AKO

goblin bomber unit come from the age of wonder mod.
elite spearman unit come from the call of arda mod.
mindwhiper, balloonist, nautilus, black scorpion, pikeman units were designed by TA Biohazard.
avalanche unit was made by PDG.
thunder hand unit come from the cursed faction.
Ice yeti, weather spire units come from the azurian faction.
Salamander unit made by Red warlord.
royal guard created by TDFedit.
aegis tower, war bot created by vaerun.
stinger bomber created by aquadraconicus.
army ant and giant spider, sky demon units were created by Kylin.
(cursed mummy, sea guardian, devourer, trapdoor spider units comes from the campaign.)

all other 3rd party models, textures and animations used are not made by me.
i don't know who made those units so i ll just credit the "unknown modder" :)

disclaimer : all unit added to the mod were modified to some extent so they are quite different from their original design.

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

i also want to thank Vaerun and Deekay for providing me help in understanding and fixing some TA:K stuff and West for testing the mod with me and providing some feedback.
(And thanks to deekay's site alltakdownload for providing me all the tools, mods and game files i needed to make this mod.)

